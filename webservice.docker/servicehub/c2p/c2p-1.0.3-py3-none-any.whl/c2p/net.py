"""
Construct PyPSA Network
Updated for PyPSA 1.0+ API (madd -> add with DataFrame)
"""

import logging

import pandas as pd
import pypsa

log = logging.getLogger(__name__)

# Custom transformer types for 20/0.4 kV that are not in PyPSA standard library
# Parameters based on standard distribution transformer specifications
# vsc = short-circuit voltage (%), vscr = resistive part (%), pfe = iron losses (kW), i0 = no-load current (%)
# Naming convention matches PyLovo: Tr_250, Tr_400, Tr_630 (kVA sizes)
CUSTOM_TRANSFORMER_TYPES = {
    # PyLovo standard sizes (250, 400, 630 kVA)
    'Tr_250': {
        'f_nom': 50.0, 's_nom': 0.25, 'v_nom_0': 20.0, 'v_nom_1': 0.4,
        'vsc': 4.0, 'vscr': 1.0, 'pfe': 0.6, 'i0': 0.4,
        'phase_shift': 150.0, 'tap_side': 0, 'tap_neutral': 0, 'tap_min': -2, 'tap_max': 2, 'tap_step': 2.5
    },
    'Tr_400': {
        'f_nom': 50.0, 's_nom': 0.4, 'v_nom_0': 20.0, 'v_nom_1': 0.4,
        'vsc': 4.0, 'vscr': 1.05, 'pfe': 0.93, 'i0': 0.35,
        'phase_shift': 150.0, 'tap_side': 0, 'tap_neutral': 0, 'tap_min': -2, 'tap_max': 2, 'tap_step': 2.5
    },
    'Tr_630': {
        'f_nom': 50.0, 's_nom': 0.63, 'v_nom_0': 20.0, 'v_nom_1': 0.4,
        'vsc': 4.0, 'vscr': 1.06, 'pfe': 1.3, 'i0': 0.32,
        'phase_shift': 150.0, 'tap_side': 0, 'tap_neutral': 0, 'tap_min': -2, 'tap_max': 2, 'tap_step': 2.5
    },
    # Legacy names for backward compatibility
    '0.25 MVA 20/0.4 kV': {
        'f_nom': 50.0, 's_nom': 0.25, 'v_nom_0': 20.0, 'v_nom_1': 0.4,
        'vsc': 4.0, 'vscr': 1.0, 'pfe': 0.6, 'i0': 0.4,
        'phase_shift': 150.0, 'tap_side': 0, 'tap_neutral': 0, 'tap_min': -2, 'tap_max': 2, 'tap_step': 2.5
    },
    '0.4 MVA 20/0.4 kV': {
        'f_nom': 50.0, 's_nom': 0.4, 'v_nom_0': 20.0, 'v_nom_1': 0.4,
        'vsc': 4.0, 'vscr': 1.05, 'pfe': 0.93, 'i0': 0.35,
        'phase_shift': 150.0, 'tap_side': 0, 'tap_neutral': 0, 'tap_min': -2, 'tap_max': 2, 'tap_step': 2.5
    },
    '0.63 MVA 20/0.4 kV': {
        'f_nom': 50.0, 's_nom': 0.63, 'v_nom_0': 20.0, 'v_nom_1': 0.4,
        'vsc': 4.0, 'vscr': 1.06, 'pfe': 1.3, 'i0': 0.32,
        'phase_shift': 150.0, 'tap_side': 0, 'tap_neutral': 0, 'tap_min': -2, 'tap_max': 2, 'tap_step': 2.5
    },
    # Extended sizes for larger installations
    '0.1 MVA 20/0.4 kV': {
        'f_nom': 50.0, 's_nom': 0.1, 'v_nom_0': 20.0, 'v_nom_1': 0.4,
        'vsc': 4.0, 'vscr': 1.2, 'pfe': 0.35, 'i0': 0.5,
        'phase_shift': 150.0, 'tap_side': 0, 'tap_neutral': 0, 'tap_min': -2, 'tap_max': 2, 'tap_step': 2.5
    },
    '0.16 MVA 20/0.4 kV': {
        'f_nom': 50.0, 's_nom': 0.16, 'v_nom_0': 20.0, 'v_nom_1': 0.4,
        'vsc': 4.0, 'vscr': 1.3, 'pfe': 0.46, 'i0': 0.45,
        'phase_shift': 150.0, 'tap_side': 0, 'tap_neutral': 0, 'tap_min': -2, 'tap_max': 2, 'tap_step': 2.5
    },
    '0.8 MVA 20/0.4 kV': {
        'f_nom': 50.0, 's_nom': 0.8, 'v_nom_0': 20.0, 'v_nom_1': 0.4,
        'vsc': 6.0, 'vscr': 1.325, 'pfe': 1.9, 'i0': 0.3,
        'phase_shift': 150.0, 'tap_side': 0, 'tap_neutral': 0, 'tap_min': -2, 'tap_max': 2, 'tap_step': 2.5
    },
    '1 MVA 20/0.4 kV': {
        'f_nom': 50.0, 's_nom': 1.0, 'v_nom_0': 20.0, 'v_nom_1': 0.4,
        'vsc': 6.0, 'vscr': 1.2, 'pfe': 2.3, 'i0': 0.28,
        'phase_shift': 150.0, 'tap_side': 0, 'tap_neutral': 0, 'tap_min': -2, 'tap_max': 2, 'tap_step': 2.5
    },
}


def add_custom_transformer_types(network):
    """Add custom transformer types to the network if not already present."""
    for ttype, params in CUSTOM_TRANSFORMER_TYPES.items():
        if ttype not in network.transformer_types.index:
            network.transformer_types.loc[ttype] = params
            log.info('Added custom transformer type: %s', ttype)


def create_network_df(model_id, timesteps, df_bus, df_trafo, df_line, df_gen=pd.DataFrame(), gen_pset=pd.DataFrame(), df_load=pd.DataFrame(), load_pset=pd.DataFrame()):      
    """ 
    Creates a PyPSA network with buses, trafos, lines, generators, loads

    Parameters
    ----------
    model_id : str
        name of model
    timesteps : int
        length of snapshots/timeseries
    df_bus : pandas.DataFrame
        
    df_trafo : pandas.DataFrame

    df_line : pandas.DataFrame

    df_gen : pandas.DataFrame
    
    gen_pset : pandas.DataFrame 

    df_load : pandas.DataFrame

    load_pset : pandas.DataFrame
    
    Returns
    ----------
    network : pypsa.Network
        pypsa network component
    """   
    # Create network container
    network = pypsa.Network(name=model_id)
    log.info('Create PyPSA network')
    
    # Add custom transformer types that are not in PyPSA standard library
    add_custom_transformer_types(network)
    
    # Set time varying data first (required before adding components with time series)
    network.set_snapshots(range(0, timesteps, 1))
    
    #------------------------------------------------------------------------------------------------------    
    # Add buses (PyPSA 1.0+ supports DataFrame-based add())
    if not df_bus.empty:
        # Prepare DataFrame with required columns
        buses_df = pd.DataFrame(index=df_bus.index)
        buses_df['v_nom'] = df_bus['v_nom']
        network.add("Bus", buses_df.index, v_nom=buses_df['v_nom'])
        log.info('Added %d Buses', len(buses_df))
    #------------------------------------------------------------------------------------------------------    
    # Add trafos (vectorized)
    if not df_trafo.empty:
        num_parallel = df_trafo['num_parallel'] if 'num_parallel' in df_trafo.columns else 1
        
        # Validate transformer types - check all are in library (including custom types)
        valid_trafo_types = set(network.transformer_types.index)
        trafo_types = df_trafo['type'].copy()
        for idx, ttype in trafo_types.items():
            if ttype not in valid_trafo_types:
                # Fallback if still not found
                log.warning('Transformer type "%s" not found, using "0.4 MVA 20/0.4 kV"', ttype)
                trafo_types[idx] = '0.4 MVA 20/0.4 kV'
        
        network.add(
            "Transformer",
            df_trafo.index,
            bus0=df_trafo['bus0'],
            bus1=df_trafo['bus1'],
            type=trafo_types,
            num_parallel=num_parallel
        )
        log.info('Added %d Trafos', len(df_trafo))
    else:
        log.info('Not added: PyPSA network has no trafos')
    #------------------------------------------------------------------------------------------------------
    # Add lines (vectorized)
    if not df_line.empty:
        num_parallel = df_line['num_parallel'] if 'num_parallel' in df_line.columns else 1
        network.add(
            "Line",
            df_line.index,
            bus0=df_line['bus0'],
            bus1=df_line['bus1'],
            type=df_line['type'],
            length=df_line['length'],
            num_parallel=num_parallel
        )
        log.info('Added %d Lines', len(df_line))
    else:
        log.warning('Not added: PyPSA network has no lines')
    #------------------------------------------------------------------------------------------------------
    # Add generators (vectorized)
    if not df_gen.empty:
        control = df_gen['control'] if 'control' in df_gen.columns else 'PQ'
        network.add(
            "Generator",
            df_gen.index,
            bus=df_gen['bus'],
            control=control
        )
        # Set time series for generators
        if not gen_pset.empty:
            for gen_name in df_gen.index:
                if gen_name in gen_pset.columns:
                    network.generators_t.p_set[gen_name] = gen_pset[gen_name].values
        log.info('Added %d Generators', len(df_gen))
    else:
        log.info('Not added: PyPSA network has no generators')
    #------------------------------------------------------------------------------------------------------
    # Add loads (vectorized)
    if not df_load.empty:
        network.add(
            "Load",
            df_load.index,
            bus=df_load['bus']
        )
        # Set time series for loads
        if not load_pset.empty:
            for load_name in df_load.index:
                if load_name in load_pset.columns:
                    network.loads_t.p_set[load_name] = load_pset[load_name].values
        log.info('Added %d Loads', len(df_load))
    else:
        log.info('Not added: PyPSA network has no loads')
        
    return network
